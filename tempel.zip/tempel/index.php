<?php
include 'functions.php';

?>

<?= template_header('Home') ?>

<div class="content">
	<h2>WVSA</h2>
	<p>Selamat Datang di CRUD AKU </p>
	<p>Tekan List Kontak di pojok kiri atas</p>
</div>

<?= template_footer() ?>